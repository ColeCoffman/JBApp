import 'react-native-gesture-handler';
import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View, Image, Button, Dimensions, ActivityIndicator } from 'react-native';
import React, { useState, useEffect } from "react";
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createDrawerNavigator } from '@react-navigation/drawer';
import EventCalendar from 'react-native-events-calendar'


let { width } = Dimensions.get('window')

function LogoTitle() {
  return (
    <Image
      style={{ width: 197, height: 45 }}
      source={require('./assets/JBLogo.png')}
    />
  );
}

function HomeScreen() {
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      <Text>Home Screen</Text>
    </View>
  );
}

// const events = [
//   { start: '2022-04-24 08:00:00', end: '2022-04-24 12:00:00', title: 'JB22 5K Fun Run', summary: 'Landshark Bar and Grill, 471 S Atlantic Ave, Daytona Beach, FL 32118\n\nJoin the Jeep Beach excitement for this fun 5K & Fun Run with Jeep Beach Week fans from across the country!' },
//   { start: '2022-04-24 12:00:00', end: '2022-04-25 00:00:00', title: 'Jeep Beach Scavenger Hunt', summary: 'Kickoff 12:00 PM\n\nTo participate, download the Goose Chase Scavenger Hunt APP\n\n' },
//   { start: '2022-04-24 12:00:00', end: '2022-04-24 18:00:00', title: 'Jeep Beach Food Truck Festival', summary: 'Tanger Outlets, 1100 Cornerstone Blvd, Daytona Beach, FL 32117. North Parking Lot\n\nJoin us for the Jeep Beach Food Truck Festival, Sunday, April 24 from 12 pm-6 pm, North parking lot at Tanger Daytona Beach, sponsored by Touch of Magic Events.\n\nJeepers will find a VIP parking area for all Jeeps and also Jeep Beach tables within the event.\n\nProceeds benefit Jeep Beach 501c3 charity, event is open to the public.' },
//   { start: '2022-04-25 09:00:00', end: '2022-04-25 16:00:00', title: 'Registration', summary: 'Daytona International Speedway, Gate 70, Midway Ave, Daytona Beach, FL\n\nGate 70 is your information hub where you can pick up items related to your JB21 registration.\n' },
//   { start: '2022-04-25 18:00:00', end: '2022-04-25 21:00:00', title: 'Jeep Beach Gives Back Charity Softball Game', summary: 'Jackie Robinson Ballpark, 105 E. Orange Ave, Daytona Beach, FL 32114\n\nA night of fun to celebrate Jeep Beach charities with some of our local charities on site in the pavilion for you to visit.\n\nWe will have a family friendly event with a celebrity softball game as well as activities for the kids with a balloon twister and both the Jeep Beach and Tortugas mascots.\n\nThere will be vendors on site with raffles for a number of items valued at >$250.00 and given away at the end of the evening.\n\nLaura Ashley Live Art will be painting onsite along with our favorite Moonshiners, Kelly Williamson and Brian Barnwell.\n\nCome out and enjoy this kickoff event full of Jeep Beach fun.\n\nAll of our Boosters and VIP are invited to an evening in the Bull Pen with food and beverage and VIP parking.' },
//   { start: '2022-04-26 09:00:00', end: '2022-04-26 16:00:00', title: 'Registration', summary: 'Daytona International Speedway, Gate 70, Midway Ave, Daytona Beach, FL\n\nGate 70 is your information hub where you can pick up items related to your JB21 registration.\n' },
//   { start: '2022-04-26 16:00:00', end: '2022-04-26 18:00:00', title: 'Jeep Beach at the Motorsports Hall of Fame of America', summary: 'Motorsports Hall of Fame of America, 1801 W International Speedway Blvd, Daytona Beach, FL 32114\n\nCome out and enjoy a walk through this iconic museum full of exhibits honoring all forms of motorsports: cars, bikes, planes and powerboats, saluting 250+ “Heroes of Horsepower” inducted to date.\n\nThere will be tours and speakers as well as the acoustic sounds of Jason Webb of the Caribbean Chillers playing while you explore.\n\nVIP/Boosters will have free entrance (be sure to wear your VIP/Booster Lanyards to gain access).' },
//   { start: '2022-04-26 18:00:00', end: '2022-04-26 21:00:00', title: 'Jeep Beach in Boots', summary: 'ONE Daytona, Victory Circle, 1 Daytona Blvd, Daytona Beach, FL 32114\n' },
// ]



function EventScreen() {
  const [isLoading, setIsLoading] = React.useState(true);
  const [events, setEvents] = React.useState([]);
  refreshEvents.bind(this);

  function refreshEvents(){
    fetch('https://sk8server.me/api/events/read.php',{
      method: 'GET',
      headers: ({
        'Accept': 'application/json',
      })
    }).then((response) => response.json())
    .then((responseJson) => {
      setEvents(responseJson['data']);
      setIsLoading(false);
      // console.log(responseJson['data']);
    }).catch((error) => {
      console.error(error);
    });
    console.log("Refreshed");
  }

  EventScreen.refreshEvents = refreshEvents;

  useEffect(() => {
    refreshEvents();
  }, [JSON.stringify(events)])


  if(!isLoading){
  return (
    <EventCalendar
      eventTapped={(event) => console.log(event)}
      events={events}
      width={width}
      initDate={'2022-04-24'}
    />
  );
  } else {
    return (
      <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
        <ActivityIndicator size="large" color="#01a8cf" />
      </View>
    );
  }
}


const Drawer = createDrawerNavigator();

function MyDrawer() {
  return (
    <Drawer.Navigator>
      <Drawer.Screen 
      name="Home"
      component={HomeScreen}
      options={{
        title: 'Home',
        headerTitle: (props) => <LogoTitle {...props} />,
      }}
       />
      <Drawer.Screen name="Events"
      component={EventScreen}
      options={{
        title: 'Events',
        headerRight: (props) => <Button title="Refresh" onPress={() => EventScreen.refreshEvents} />,
      }}

       />
    </Drawer.Navigator>
  );
}

export default function App() {
  return (
    <NavigationContainer>
      <MyDrawer />
    </NavigationContainer>
  );
}